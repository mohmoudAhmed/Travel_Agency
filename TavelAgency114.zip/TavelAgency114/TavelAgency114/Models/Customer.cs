﻿using System.ComponentModel.DataAnnotations;

namespace TravelAgency111.Models
{
    public class Customer
    {
        // Primary Key (PK)
        public int Id { get; set; }

        public string? FirstName { get; set; }

        public string? LastName { get; set; }

        public string? Email { get; set; }

        public string? Phone { get; set; }

        // Navigation property to Bookings (related entity)
        public ICollection<Booking>? Bookings { get; set; }
    }

}
