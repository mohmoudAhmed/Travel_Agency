﻿using System.ComponentModel.DataAnnotations;

namespace TravelAgency111.Models
{

    public class Destination
    {
        // Primary Key (PK)
        public int Id { get; set; }

        public string? Name { get; set; }

        public string? Country { get; set; }

        public string? Description { get; set; }

        public string? ImageUrl { get; set; }

        // Navigation property to Packages (One-to-Many)
        public ICollection<Package>? Packages { get; set; }  // Add this line
    }

}
