﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace TravelAgency111.Models
{

    public class Payment
    {
        // Primary Key (PK)
        public int Id { get; set; }

        // Foreign Key (FK) referencing Booking
        [ForeignKey("BookingId")]
        public int BookingId { get; set; }

        public decimal AmountPaid { get; set; }

        public DateTime PaymentDate { get; set; }

        public string? PaymentMethod { get; set; }

        // Navigation property to Booking (related entity)
        public Booking? Booking { get; set; }
    }

}
