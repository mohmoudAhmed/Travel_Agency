﻿using System.ComponentModel.DataAnnotations.Schema;

namespace TravelAgency111.Models
{
    public class Booking
    {
        // Primary Key (PK)
        public int Id { get; set; }

        // Foreign Key (FK) referencing Customer
        [ForeignKey("CustomerId ")]
        public int CustomerId { get; set; }

        // Foreign Key (FK) referencing Package
        [ForeignKey("PackageId")]
        public int PackageId { get; set; }

        public DateTime BookingDate { get; set; }

        public decimal TotalPrice { get; set; }

        // Navigation property to Package (related entity)
        public Package? Package { get; set; }

        // Navigation property to Customer (related entity)
        public Customer? Customer { get; set; }

        // Navigation property to Payment (related entity)
        public Payment? Payment { get; set; }
    }

}
