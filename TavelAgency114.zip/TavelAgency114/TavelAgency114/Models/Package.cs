﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace TravelAgency111.Models
{
    public class Package
    {
        // Primary Key (PK)
        public int Id { get; set; }

        public string? Name { get; set; }

        public decimal Price { get; set; }

        public string? Description { get; set; }

        public int DurationInDays { get; set; }

        // Foreign Key (FK) referencing Destination
        [ForeignKey("DestinationId")]
        public int DestinationId { get; set; }

        // Navigation property to Destination (related entity)
        public Destination? Destination { get; set; }

        // Navigation property to Bookings (related entity)
        public ICollection<Booking>? Bookings { get; set; }
    }

}
